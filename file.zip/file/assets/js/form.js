	
$(document).ready(function(){
  var current = 1,current_step,next_step,steps;
  steps = $("fieldset").length;
  $(".next").click(function(){
    current_step = $(this).parent();
    next_step = $(this).parent().next();
    next_step.show();
    current_step.hide();
    setProgressBar(++current);
  });
  $(".previous").click(function(){
    current_step = $(this).parent();
    next_step = $(this).parent().prev();
    next_step.show();
    current_step.hide();
    setProgressBar(--current);
  });
  setProgressBar(current);
  // Change progress bar action
  function setProgressBar(curStep){
    var percent = parseFloat(100 / steps) * curStep;
    percent = percent.toFixed();
    $(".progress-bar")
      .css("width",percent+"%")
      .html(percent+"%");   
  }
  $( "#user_form" ).submit(function(event) {    
    var error_message = '';
    if(!$("#surname").val()) {
      error_message+="Please Fill Your Surname";
    }
    if(!$("#firstname").val()) {
      error_message+="<br>Please Fill Your Firstname";
    }
    if(!$("#date").val()) {
      error_message+="<br>Please Fill Your Date of Birth";
    }
    if(!$("#address").val()) {
      error_message+="<br>Please Fill Your Resident Address";
    }
    if(!$("#place").val()) {
      error_message+="<br>Please Fill Your State of Origin";
    }
    if(!$("#nationality").val()) {
      error_message+="<br>Please Fill Your Nationality";
    }
    if(!$("#fname").val()) {
      error_message+="<br>Please Fill Your Father's Name";
    }
    if(!$("#occupation").val()) {
      error_message+="<br>Please Fill Your Father's Occupation";
    }
    if(!$("#add").val()) {
      error_message+="<br>Please Fill Your Father's Address";
    }
    if(!$("#fone").val()) {
      error_message+="<br>Please Fill Your Father's Phone No";
    }
    if(!$("#mname").val()) {
      error_message+="<br>Please Fill Your Mother's Name";
    }
    if(!$("#moccupation").val()) {
      error_message+="<br>Please Fill Your Mother's Occupation";
    }
    if(!$("#mfone").val()) {
      error_message+="<br>Please Fill Your Mother's Phone No";
    }
    if(!$("#plat_img").val()) {
      error_message+="<br>Please upload your picture";
    }
    if(!$("#signature").val()) {
      error_message+="<br>Please upload your signature";
    }
    if(!$("#department").val()) {
      error_message+="<br>Please Fill Your Department";
    }
    if(!$("#name").val()) {
      error_message+="<br>Please Fill Your Next of Kin Name";
    }
    if(!$("#kin_add").val()) {
      error_message+="<br>Please Fill Your Next of Kin Address";
    }
    if(!$("#kin_phone").val()) {
      error_message+="<br>Please Fill Your Next of Kin Phone No";
    }
    if(!$("#relationship").val()) {
      error_message+="<br>What is your realtionship with your Next of Kin";
    }
    if(!$("#username").val()) {
      error_message+="<br>Please Fill  Your Username";
    }
    if(!$("#email").val()) {
      error_message+="<br>Please Fill  Your Email Address";
    }
    if(!$("#password").val()) {
      error_message+="<br>Please Fill Password";
    }
    if(!$("#cpassword").val()) {
      error_message+="<br>Please Fill  Your confirmed Password";
    }
    
    // Display error if any else submit form
    if(error_message) {
      $('.alert-success').removeClass('hide').html(error_message);
      return false;
    } else {
      return true;	
    }    
    });
});
